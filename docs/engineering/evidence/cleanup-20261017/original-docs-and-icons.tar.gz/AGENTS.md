## CURRENT FINAL STABILIZATION — 2026-10-16

Owner requested stabilization, not another UI reconstruction. Implementation
`f92fe04` fixes the three valid channel-energy LUFS regressions, unavailable-evidence
normalization, recorder ownership and late-disposal/B-crop publication defects;
`5a1e10d` adds production file-origin proof. Original assertions/tolerances retained.
Clean published suite **365/365 PASS**; broader held tree **555/555 PASS**; zero
fail/skip/TODO. Final browser **22 groups / 13 downloads / 32 genuine PNGs**, both
sizes/all key states; source/build hashes and release gates are in
[final stabilization](docs/engineering/STABILIZATION_20261016.md).

Presentation/reference pack/native shell/dependencies/models/storage/undo/IPC are
unchanged; no broader core or UI reopening is authorized. Unrelated held work stays
unpublished. Meter remains ungated/approximate, not standards-grade; native Mac,
security remediation and listening remain gates. Older delivery counts/status below
are historical, not the final stabilization result. Git/PR4 is publication authority;
publication does not imply P receipt/start or native/product acceptance.

# MusicOnVerse agent collaboration rules

## CURRENT DELIVERY AUTHORITY — 2026-10-16

The owner explicitly RELEASED the held app integration for recovery, publication
and safe reconciliation. The former UI source-publication hold is superseded.
Authoritative app: `arena/14df8ffa-onverse` / PR4, recovery6199230, normal8051
history reconciliation3f429dd, cinematic implementation6a9369a. Main remains2faa3939;
no main/PR8 merge or product/native acceptance is implied. See
[delivery verification](docs/engineering/DELIVERY_VERIFICATION_20261016.md) and
[full reference review](docs/design/REFERENCE_REVIEW_20261016.md).

P is UI agent; B is retired. P7e105a0's six latest presentation paths were reviewed
and integrated byte-identically. Lead owns main/index, workbench/analysis wiring,
`src/ui/workbench/**` host adapter and combined tests; P retains presentation scope
`src/ui/presentation/rebuild/**`. Compare exact published source before reconciling
P's dirty tree; preserve .arena/artifacts/untracked/core. Coordinate scoped future
deltas directly through GitHub, not owner relay or repeated ordinary approvals.
No concurrent overwrite, blind pull/reset/clean, force/history rewrite, branch
switch or unrelated held-core publication. DSP/models/storage/IPC/security/native
lifecycle remain protected. No hidden old UI or fake DAW/SYLUNE capabilities.

References01–13 are recovered/individually reviewed at project900f0733.13system,
02first-person cosmic,05/09precision,04framing-only are current. Browser proof is
actual root production entry, not the P preview. Clean published suite272tests
(269pass/3knownTODO); broader dirty suite462(459pass/3TODO) includes unpublished
core drafts. Both real viewports/motion/dialog/reduced-motion/audio proof passed
with declared CPU raster; SwiftShader emulation stalls and native/Mac limits are
explicit in the report. Older conflicting authority/status below is historical.

## CURRENT OWNER AUTHORITY — UI-RESET-001 / 2026-10-16

**P is the UI agent; B is retired.** The owner authorized a complete frontend reset,
not a restyle. [UI_RESET_AUTHORITY](docs/engineering/UI_RESET_AUTHORITY.md) and its
pre-deletion168path inventory supersede every conflicting B reservation, old board,
font/palette/layout direction and Orbit/fallback requirement below. P owns approved
presentation deletion/replacement; design waits for NEW owner references. No hidden
old frontend/fallback. SYLUNE keeps its name. Core/DSP/services/history/storage/IPC/
lifecycle/contracts stay protected; main.js, DTO/test and icon/build crossings need
exact shared review. No whole-main deletion, force/ref rewrite or repository wipe.
Publication is not P receipt/start. Older B-specific grants below are historical,
not active authority. Do not concurrently edit P's presentation files. See the new
record for the main/core baseline mismatch, protected held work and execution gates.


## Owner-requested Agent B follow-up prompts

Whenever the user supplies an Agent B report and lead resolves/communicates it
through a PR, also give the user a **copyable follow-up prompt** telling Agent B
what is resolved, the direct decision link, exact continuing boundaries and that
it may proceed within the grant. Do not substitute a PR comment for this user-
facing prompt or claim worker receipt/start without evidence. Include the prompt
before returning to independent core work when the user requests that order.

## CURRENT OWNER RESOLUTION — COORD-010 / 2026-10-16

[Exact published owner resolution](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6213314954). Publication is not worker receipt/start or acceptance.

[Universe handoff](docs/engineering/UNIVERSE_VISUAL_HANDOFF.md) is current for this
visual work and **narrows conflicting earlier broad renderer/Orbit permissions**.
Approved: shared Three.js universe modules `src/ui/presentation/universe/**` and
only necessary `src/main.js` factory/ORBIT_SPIKE wiring behind unchanged
`createStage(canvas)` public contract. Studio restyling/approved presentation
modules continue; no new directory-wide permission, unrelated renderer change or
additional dependency. Lead still freezes B's presentation/shared source files.

`src/orbit/orbitStage.js` is NOT unrestricted: inspected plan needs **no edits**
there initially; preserve it as rollback. Any necessary camera/motion diff requires
exact hunks/reason/tests and only that change's approval. Latest approved boards
control opening-universe AND DAW fidelity/palette: violet/magenta/electric-blue/
cyan/warm highlights, not monochrome purple/neon/steel-blue. Exact art provenance
and font licenses/notices required; Sora candidate reviewed in linked handoff,
existing fonts stay fallback until integration verified. No fictitious owner color
ban; quote/source any actual conflict. Baseline/revised performance, reduced motion,
1480x920 studio inspection and both board comparisons required before completion.

Core/audio/real SYLUNE/models/storage/IPC/security/build/dependency boundaries and
honest unsupported controls remain. No unrelated engine blocker stalls visuals.
No Git rewrite/switch/merge/release or held-core commit/push authorization.

## Historical broad grant — COORD-010 / 2026-10-15 (amended above)

The owner delegates **full creative and implementation authority over the visual
experience to Agent B**. [Exact published authorization](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6202569659);
[handoff section 11](docs/engineering/UI_IMPLEMENTATION_HANDOFF.md).
**No further lead approval for ordinary design, layout, styling, visual rendering,
scene/camera/animation, responsiveness, interactions or presentation refactoring.**
Escalate only genuine core crossings, new architectural/core contracts, or risks
to an existing functional workflow. Coordination/file-plan reports are not design
approval gates; independent UI work continues while core integrations are pending.

Agent B exclusively reserves presentation responsibilities in `src/main.js`,
`src/ui/draw.js`, `src/scene.js`, related `src/scene/**`, `src/orbit/**`, `src/ui/**`,
`src/style.css`, `index.html`, related visual styles/assets/fonts and UI/Orbit/scene
tests. May restructure/replace components and internal visual APIs with owned
callers/tests. No transfer of core merely by moving it into a UI directory.
**Lead freezes all edits in reserved presentation files, including whole shared
main.js/draw.js/scene.js, until explicit release/re-handoff.**

Visual rendering/geometry/camera/effects are Agent B's; audio rendering/DSP,
functional SYLUNE, authoritative session/track models, application/domain logic,
storage/history/recovery, IPC/security, dependencies/build configuration and other
core services remain lead-owned. Shared main.js presentation refactors must
preserve functional state/action/service semantics; request exact core interfaces
rather than inventing or bypassing them. Coordinator canonical records remain
lead-owned; the existing non-canonical proposal remains Agent B's.

Full professional DAW/Orbit/SYLUNE/cosmic presentation and honest prototypes are
authorized. Never imply unsupported operations work or fabricate audio/AI results.
Preserve working workflows; document necessary impacts and escalate genuine risk.
Run relevant tests/builds; verify keyboard/accessibility, reduced motion,
performance, and actual 1120x700/1480x920 screenshots. Report gaps honestly.

This grant **supersedes** earlier narrow file lists, colour-only/geometry/camera/
CSS-only/no-extra-visual-renderer/RAF and routine design-approval restrictions,
not core safeguards or honest capability boundaries. Prior passages below are
historical wherever inconsistent. Existing submissions/work remain preserved,
not retroactively accepted. Continue fixed existing sessions/branches with bounded
reviewable commits. No destructive Git/ref realignment/history rewrite/switch/
merge/unrelated overwrite is authorized. Publication is not receipt/start.

## Historical canvas palette exception — COORD-009 / UI-008, 2026-10-15

[Published exact grant](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6202421591) resolves the canvas colour gap.
Agent B now exclusively reserves **colour-only edits** to `src/ui/draw.js` and
`src/scene.js`, plus optional `src/ui/presentation/canvasPalette.js` and
`tests/ui/canvasPalette.test.js`. Existing B-owned presentation scope testing may
add these exact paths. No broad directory grant or semantic ownership transfer.

**Lead freezes both whole shared files until explicit worker release/re-handoff.**
Core retains drawing/stage semantics/API ownership, without concurrent edits.
Only decorative RGB/hex/theme projection changes: preserve alpha/opacity, blending,
gradient positions, geometry, data/peak/audio math, camera/motion, input, lifecycle
and public APIs. No extra renderer/RAF/dependency. Reuse current theme, preserve
waveform/status meaning; see handoff section 10 for complete validation/boundaries.
This prospectively supersedes earlier blanket draw.js/scene.js denials only for
UI-008. `src/scene/**` and all other core paths remain outside the grant.

Worker PR #5 at 0a9b164 reports UI-006/007 delivered (submitted, not accepted),
53 tests/build/browser evidence; lead has read the report, not reproduced those
new checks. UI-005 remains submitted/partial. UI-008 ready; worker acknowledgment
before editing, no further approval reply. SYLUNE execution/multitrack engine stay
core work and do not block the inert prototype/palette. No ref realignment, Git
history rewrite, merge or session switch is authorized.

## Previous blocker resolution — COORD-008 / UI-006 / UI-007, 2026-10-15

[Four explicit decisions](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6201768819) supersede repeated reported blockers.
Agent B's exclusive presentation-only `src/main.js` and
`src/ui/presentation/sylune/**` reservation is **active** for header/panel/contextual
Ask SYLUNE. Honest inert PROTOTYPE multitrack/timeline/mixer design is authorized;
older no-invented-mixer wording does not block it. Core behaviour is not granted.

**Workspace-wide cosmic restyle is authorized now through the shared-shell
alternative:** Agent B may add `src/ui/presentation/cosmicEnvironment.js`,
`src/ui/styles/cosmic.css`, `tests/ui/cosmicEnvironment.test.js`, with presentation
main/style mounting. One persistent non-interactive CSS/local-procedural layer,
shared tokens, no extra renderer/RAF; Orbit uses its real canvas without duplicate
decorative planets. Legacy stage and audio-reactive calls remain intact. Lead
retains `src/scene.js`, `src/scene/**`, `src/ui/draw.js` and functional contracts;
Agent B keeps its Orbit reservation. No concurrent lead edits in UI allowlist.

UI-005 is submitted/partial, not accepted: existing 7222704 implementation and
recorded 36 passing tests; 1480x920/reference/runtime gates remain. UI-006 and
UI-007 are ready. Worker records its own preservation/file plan before editing
and proceeds without another approval reply; no receipt/start is claimed.
Use the [handoff section 9](docs/engineering/UI_IMPLEMENTATION_HANDOFF.md) and
[queue](docs/engineering/WORK_QUEUE.md). Preserve all existing work and fixed
branches; no merge, history rewrite, session switch or new dependency.

## Earlier continuation decision — COORD-007 / UI-006 / 2026-10-15

**SYLUNE** is the intended producer/engineering agent. Full professional DAW
structure/workflows use Logic Pro; Reference 1 remains the visual target. Later
owner instructions authorize honest future DAW concepts and explicitly labelled
SYLUNE presentation prototypes, not fabricated engine capabilities.

The [published decision](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6201376526) and
[SYLUNE presentation contract](docs/engineering/SYLUNE_PRESENTATION_CONTRACT.md)
extend Agent B's exclusive **presentation-only `src/main.js`** reservation to
SYLUNE panel/header/contextual wiring and `src/ui/presentation/sylune/**`. Lead
freezes these UI paths; core/application/domain/audio/storage/IPC remain lead-owned.
UI-006 is ready pending worker's own current preflight/file-plan acknowledgment,
not claimed running. This supersedes earlier blanket no-prototype wording only
within the bounded truthful presentation grant; original safety/deny paths stand.

Live UI delivery: draft PR #5 at `7222704026cf50fe8b62b212c7da5640e62381f5`.
UI-004 and UI-005 are submitted, not accepted. Existing Orbit partially fulfills
UI-005; continuation reservation is `src/orbit/{orbitStage,orbitTextures,orbitKeys}.js`
and `tests/orbit/{orbitStage,orbitKeys}.test.js`, with presentation main/style wiring.
Do not duplicate it or treat the old not-dispatched notice as current. Required
reference/runtime acceptance remains open. Published acknowledgment on PR #3 and
PR #5 results are evidence of communication/work, not current process inspection.

Current lead is fixed to `arena/14df8ffa-onverse`; older lead branch tables below
are historical, never instructions to switch. Actual main remains `2faa393` at
this audit. PR #4's proof head is `8051fe0`; local minimum Linked Sessions contract
starts at `4d48cb1`. Neither proofs nor contracts constitute integrated Linked
Sessions, a full DAW or SYLUNE execution. Preserve all sessions/workspaces/work.
No new PR approval/merge, dependency, provider, upload or cost is authorized here.
Subsequent UI HEAD `8a2e712` adds only the non-canonical
`docs/design/proposals/agent-b-daw-sylune-proposal.md`; it is preserved and may be
updated by Agent B as an exact-file proposal exception, not a competing canonical
brief or authority to edit core. Source tests above are pinned to unchanged 7222704.

## Scope and authority

- The product owner sets product scope/direction and decides major core architecture, dependencies, costs and destructive actions. COORD-010 delegates ordinary visual design and implementation decisions to Agent B without per-decision approval.
- The lead/coordinator owns architecture, application contracts, core audio engineering, task assignment, review, and integration recommendations.
- Codex is no longer active. The owner reports **agent-b** on fixed branch `arena/ced77c2a-onverse`; its actual checkout/runtime and acknowledgment remain independently unverified. The [2026-10-15 UI implementation handoff](docs/engineering/UI_IMPLEMENTATION_HANDOFF.md) supersedes the old read-only/main-wait restriction with a bounded Slice A grant, effective only after verified PR #3 merge M, worker preservation/ancestry preflight and published ownership acknowledgment. Onboarding alone grants nothing. COORD-010 is the current explicit full visual grant; old Slice A activation conditions are historical, not new approval gates. Workers do not independently change core architecture/contracts; Agent B may refactor owned internal presentation interfaces.
- These rules establish a Git-based collaboration protocol, not an automatic scheduler, agent launcher, or permission to implement the full roadmap.
- Follow [issue #2](https://github.com/The-Mhood/onverse/issues/2), with the product owner's later direction to defer a custom orchestration platform. No new orchestration runtime or dependency is authorized.

## Historical PR #3 integration decision (current visual authority is COORD-010)

The owner explicitly authorizes whole-PR #3 review, substantive fixes and `gh pr merge 3 --merge` if review passes. Keep agent-b on its same main-based fixed branch: after actual M is published in the COORD-006 PR #3 result, independently verify objects/ancestry/cleanliness/ignored collisions and use `git merge --ff-only M` only if its HEAD is an ancestor. Never reset/rebase/switch/force/discard to bypass divergence. No future SHA is invented. The [handoff](docs/engineering/UI_IMPLEMENTATION_HANDOFF.md) supplies the dated exclusive `src/main.js` reservation, exact allow/deny paths, settled visual/font/texture/error decisions and mechanically activated worker acknowledgment. No extra owner round-trip for these settled decisions; no claim the worker received or started the task. Old COORD-005/UI-003 notices are historical where superseded.

## Architecture references

CORE-007 explicitly reconciles three existing PR #1 proposal documents into the same canonical paths on the engineering branch, as **working drafts for review**, not implemented APIs or approved product defaults:

- [Architecture](docs/ARCHITECTURE.md): actual-state boundary, retained modular-monolith direction, proposed session/link records, dependency semantics, safe render/update/recovery and the minimum real proof.
- [Product vision](docs/PRODUCT_VISION.md): long-term intent, general Linked Sessions/manual-update promise, honest capability/design boundaries; commercial ideas remain unvalidated hypotheses.
- [Roadmap](docs/ROADMAP.md): incremental proof gates and a proposed test crosswalk, not task dispatch or executed coverage.

[PR #1](https://github.com/The-Mhood/onverse/pull/1) remains a separate unmerged draft at the inspected `eedc24cb38c21d1a4be6186593c7ae7fcb8c6f85`; source attribution is preserved in each revised document. Its original README and [engineering standards proposal](https://github.com/The-Mhood/onverse/blob/eedc24cb38c21d1a4be6186593c7ae7fcb8c6f85/docs/ENGINEERING_STANDARDS.md) are not adopted by this unit. Do not blindly merge/copy PR #1 over the revised working files; overlapping paths require explicit review. The working drafts do not satisfy an `accepted` dependency merely by existing or being published. Do not create a second competing architecture or design brief. This explicit architecture task does not relax the prohibition on adopting proposals incidentally during onboarding/coordination.

## Before every assignment

1. Read [README.md](README.md), this file, the [project guide](docs/engineering/PROJECT_GUIDE.md), the latest notices/results in [the work queue](docs/engineering/WORK_QUEUE.md), and the [canonical design brief](docs/design/DESIGN_BRIEF.md). The [agent-b master prompt](docs/engineering/AGENT_B_MASTER_PROMPT.md) supplies reusable context, not an assignment. Read the working architecture/roadmap when a task touches future state, session/link semantics or contracts; proposed interfaces are not permission to implement them.
2. Inspect the directory, current branch, full working-tree status, recent commits, remotes, and worktrees. Compare relevant local and remote refs; do not assume remote-tracking refs are current.
3. Preserve existing edits, including untracked files. Never reset, clean, stash, overwrite, force-push, switch away from active work, or remove worktrees without explicit authorization.
4. Record the task ID, exact base SHA, execution environment, owner, branch/worktree, dependencies, allowed paths, forbidden paths, acceptance criteria, and checks before editing.
5. Explain the intended changes and name the exact files to create or modify. Stop if scope, ownership, or prerequisites are unclear.
6. Respect restrictions imposed by the execution environment. If a session is fixed to a branch, do not create or switch to another branch to satisfy a worker assignment; report the isolation blocker.

## Ownership and isolation

Each worker implementation requires its own branch and separate worktree or clone, based on an explicitly approved SHA. Never run two editing agents in one working directory. Read-only audits can inspect a pinned snapshot without an editing workspace; they must not change files, install packages, or build into that checkout.

| Area | Default responsibility | Rule |
| --- | --- | --- |
| `src/audio/**` | Lead/core | DSP, measurement, processing, codecs, and reference mechanisms |
| `src/application/**`, `src/domain/**` | Lead/core | Use cases, contracts, and domain rules |
| Core unit tests, audio fixtures/tests | Lead/core | Assign exact test paths per task |
| Visual design, scenes and presentation | Agent B under amended COORD-010 | Restyling/approved modules continue; universe/main narrow stage grant; Orbit camera/motion requires exact diff |
| UI/style/visual assets and related presentation tests | Agent B under COORD-010 | May restructure/refactor presentation; preserve workflows and validate quality |
| `src/main.js` | Agent B exclusive presentation reservation | Lead freezes whole shared file; core semantics changes require coordinated interface/re-handoff |
| `src/ui/draw.js`, `src/scene.js`, visual `src/scene/**` / `src/orbit/**` | Agent B exclusive full visual reservation | Not colour-only; geometry/rendering/camera/animation permitted, audio/core contracts stay lead-owned |
| Electron, build/configuration, manifests, lockfile | Lead approval | No incidental edits or dependency changes |
| `AGENTS.md`, onboarding/context/design-brief documents, `docs/engineering/WORK_QUEUE.md` | Coordinator | Workers propose changes through task/PR results; no competing canonical briefs |

The amended COORD-010 grant above controls scope; historical broad renderer/Orbit permissions do not bypass its exact limits. Other defaults are not automatic grants. The coordinator must check actual path/prefix intersections before later shared-file assignments. A directory grant overlaps every contained file. Renames/deletes count against both affected paths. Forbidden paths win over allowed paths; changing the allowlist requires review first.

Separate branches do not resolve overlapping ownership. If two tasks need the same file, serialize them or establish a separate, approved shared-interface task. Record the active reservation and actual worker acknowledgment before edits (queue plus the linked GitHub result/acknowledgment when the scoped handoff defines mechanical activation). UI-004 reserves its exact UI paths for agent-b at the dated handoff; lead freezes them, and worker publishes preflight/ownership acknowledgment before starting. Do not release a reservation merely because a worker stopped responding.

## Task lifecycle and dispatch gates

Use the queue's task schema and states. Only `accepted` prerequisites satisfy dependencies; a commit, push, successful test, or worker's `submitted` result is not acceptance. Acceptance records the reviewer and evidence; record merge/integration separately rather than implying that acceptance means merged.

The coordinator:

- Verifies dependencies, the approved base, ownership, worker availability, and required approvals before marking a task `ready`.
- Records the assignment and worker acknowledgment before `running`.
- Blocks affected tasks when an upstream task fails, changes contracts, or loses acceptance. Stops downstream dispatch; does not silently retarget running work.
- Reviews the actual diff, changed-file ownership, test evidence, and known risks before acceptance.
- Reports the next eligible tasks and the reason each remaining task is blocked.

For now, readiness and ownership checks are manual Git/GitHub review. Do not describe them as automated enforcement.

## UI/core interface rules

Current engineering interfaces, introduced on the engineering branch:

- `analysisService.analyze(buffer, onProgress)` and `analysisService.analyzeFast(buffer, onProgress)`: asynchronous local analysis; unchanged result shapes, optional engine-defined progress, propagated errors.
- `buildProcessingPlan(base, adjustments, bandKeys)`: independent plan construction, not validation of imported or AI-generated instructions.

The analysis service does not yet provide workers, cancellation, persistent projects, or undo. UI work must not imply those capabilities exist. Do not duplicate processing logic or introduce a second authoritative processor state in UI code.

For UI-004, the owner has settled the visual target/sequence and the lead has bounded architectural compatibility in the handoff. Agent-b publishes its actual audit/preflight, file/check plan and ownership acknowledgment before implementation; do not ask the owner to reapprove Reference 1/2, ground-up presentation, self-hosting or Slice A first. Material new product/dependency/contract choices still require appropriate review. Any shared-contract change remains a separate core task; UI waits for its acceptance.

Read the canonical design brief: Reference 1 is the visual target, Reference 2 layout structure only; ground-up professional dark/celestial presentation, not an old-interface extension. Notify before look changes; derive coherent implementation tokens from the approved target and report them for review, rather than blocking on another request for the same settled decision. Material departures need review. Slice A precedes a separately assigned, feature-flagged Orbit spike; reduced-motion camera work is in the spike. Core work must not duplicate agent-b's UI work.

## Required product and safety invariants

The project guide records current capabilities and future boundaries; do not infer implementation from proposals. Source is presently a single-buffer prototype, not a multitrack/session engine.

- Preserve the working audio/UI flows and existing contracts. No broad controller/framework rewrite or new dependency without a separately approved scope.
- Future UI intent flows through validated application operations and pure domain/state transitions to async repositories/storage; no second authoritative UI model or component-localStorage project store.
- Linked Sessions is general-purpose. Track transfers, selected-track sums, actual bus stems, and full mixes are distinct. Stable IDs, pinned relevant revisions, explicit render rules, immutable managed assets, provenance, atomic commit/history, and restart recovery are required.
- Source edits never silently replace destination audio. Explicit affected-item updates must preserve destination processing/routing/automation/placement, unrelated items, and the prior valid asset on failure/cancellation/incompatibility. Use relevant dependencies, not global session revisions, for currentness; never rebind by name.
- Chains record exact used revisions and distinguish local currentness from stale upstream ancestry. No silent cascading update; reject cycles and unresolved unsafe dependencies. Future AI must use the same validated approved operations and cannot override manual linked updates.
- Imported/AI data is untrusted: parsing does not mutate active state; validate targets, units, ranges, capabilities, and permissions before approved application. No arbitrary generated code/shell/filesystem execution, silent uploads/costs, or mutable originals.
- Prove high-risk mechanisms with a minimum real end-to-end render/storage/update test before dependent expansion. Mocks alone do not prove audio quality, persistence recovery, plugin support, or cancellation.

## Verification and review

- Keep each unit small and behavior-preserving unless its accepted scope explicitly changes behavior.
- No new dependency without product-owner approval. Never hardcode credentials or silently upload audio.
- AI/model output and imported files are untrusted; workers must not bypass application validation or execute arbitrary generated code.
- Report loading/error/cancellation limitations honestly. Do not swallow errors to make checks appear successful.
- Test actual audio mechanisms when assessing correctness; mocks validate contracts, not measurement quality or hardware support.
- Never claim browser listening, macOS startup, packaging, or agent dispatch was verified unless actually executed.

Existing core checks, run from the repository root when applicable:

```bash
node --test tests/unit/*.test.js tests/audio/*.test.js
node scripts/test-analyze.mjs
npm run build
```

The current default suite has 154 tests / 151 passes / 3 explicit known LUFS TODO cases, including nine actual-controller boundary tests. No npm test/lint/typecheck/UI-test scripts are configured; report missing checks as unconfigured, never passed. Strict diagnostics and unresolved audio/gain limits are in the project guide.

A build writes ignored output: it is not part of a read-only audit or dry run. Document-only tasks should verify paths, links, scope, and whitespace; avoid dependency installation or builds unless justified. Add task-specific tests for changed behavior. UI integration also requires import, reference analysis, processing, adjustments, A/B, crop/seek, and export checks appropriate to its diff.

## Results and integration

Workers return: task ID, owner/runtime, base SHA, branch/worktree, commit(s), PR link/base, changed paths (including untracked work), commands actually run, outcomes/failures, skipped checks, blockers, risks, and requested next work.

The coordinator reconciles that report with the actual diff and GitHub checks, then updates the queue. Use commits and PRs for code delivery; never push worker changes directly to the integration branch. Do not assume a worker's local checkout is synchronized with GitHub. In particular, changes saved only in Arena are unavailable on a user's Mac until explicitly published and retrieved.

No automatic merge. Before integration, recheck the base, combined diff, affected contracts, and relevant workflows. Obtain product-owner approval for merge actions. A concurrent update to a shared file invalidates the previous conflict review.

## Failure and recovery

- Failure/interruption: mark `failed` or `blocked`, capture the last commit, working-tree/untracked-file inventory, test failures, and outstanding processes. Preserve all work.
- Conflicting paths/contracts: stop affected edits and dispatch. Record the collision and obtain an explicit sequencing/reconciliation decision; do not automatically resolve conflicts or replay changes.
- Retry: retain the task ID, append attempt history, and record the new assignment/base only after reviewing the preserved attempt.
- Abandoned worktree: inspect its status, branch, untracked/ignored material, and running processes before considering reassignment or removal. Preserve recoverable work; removal needs explicit approval.
- Integration failure: block dependent tasks and record the failing checks. Do not reset a shared branch or continue stacking features on the failure.

## Runtime and automation boundary

The audited environment has `git`, `gh`, Node/npm, and Python. No `codex`, `arena`, or `claude` executable was found on PATH, and no agent-launch API was verified. This does not establish what exists on the user's Mac.

Use `git` for local version-control operations and `gh` for GitHub PR/issue/check records when available; report access/tool blockers rather than inventing success. Broad permissions do not replace a scoped task, preservation of work, or actual integration review.

GitHub tasks, PRs, checks, and worker-authored result comments are the shared communication channel. The coordinator retrieves published results directly rather than asking the product owner to relay every task. Publishing assignments or changing GitHub records is a mutation and must be reported; local queue entries alone do not dispatch an agent.

Do not install a runtime, request secrets in chat, create a generic shell-execution adapter, or claim automatic dispatch. If automation later becomes justified, first verify an authorized runtime's launch, authentication, isolation, cancellation, and result collection. Any future dry run must dispatch no agents and make no Git or GitHub mutations or task-state/file writes. There is no orchestrator CLI or automatic dry-run mode in this documentation-only setup.
