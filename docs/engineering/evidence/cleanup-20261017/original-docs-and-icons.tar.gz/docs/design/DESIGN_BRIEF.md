## CURRENT OWNER DIRECTION — UI-RESET-003 / 2026-10-16

Proceed with the NEW rebuild:13 shared design system;02 grounded first-person
cosmic environment;05/09 professional hierarchy and precise editing;04 framing
only, not a literal DAW-window-over-space. Previous WAIT/old B boards/fonts/layout
instructions below are superseded. P owns new presentation/assets; lead owns the
functional shell/operations, with real single-buffer workflows only. No fake
multitrack/mixer/plugins/library/SYLUNE execution. Current source has no numbered
reference image files, so exact-fidelity signoff is not claimed. See
[verified startup/rebuild report](../engineering/UI_REBUILD_STARTUP_REPORT.md).

# MusicOnVerse canonical design brief

## Visual brief superseded — UI-RESET-001, 2026-10-16

The owner authorized a full UI deletion/replacement by P. All earlier visual boards,
layouts, palette/font/scene prescriptions below are historical, NOT the foundation
for the next design. Await NEW owner media. Product/core functionality remains
protected; SYLUNE retains its name. [Current authority](../engineering/UI_RESET_AUTHORITY.md).


## Current owner resolution — COORD-010, 2026-10-16

[Exact published owner resolution](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6213314954). Publication is not worker receipt/start or acceptance.

[Exact universe handoff](../engineering/UNIVERSE_VISUAL_HANDOFF.md) governs current
renderer/Orbit scope, assets/fonts and verification. Shared Three.js universe
under `src/ui/presentation/universe/**` and necessary main-stage wiring approved;
public createStage contract unchanged. Orbit stage initially unchanged/rollback;
only separately identified necessary camera/motion diffs may be approved there.
No directory-wide/unrelated-renderer/dependency expansion.

The latest approved reference boards govern **both opening universe and DAW**.
Use their rich violet, magenta, electric blue, cyan and complementary warm
highlights with realistic materials/depth and professional contrast/readability.
Not monochromatic purple, excessive neon, generic cyberpunk or default steel-blue.
Earlier board/layout/palette/font restrictions below are historical where
inconsistent with this explicit owner direction. No verified blanket owner ban
on these colors was found; quote exact owner/source if one actually exists.

High-quality original/licensed art is preferred when it improves fidelity;
record exact used assets/rights/attribution. Procedural work must meet quality,
not generic-placeholder planets. Sora conditional on exact files/license/notices,
existing fonts fallback; [candidate review](../engineering/SORA_ASSET_REVIEW.json).
Baseline/revised performance, actual reduced-motion tests, 1480x920 studio and
opening/DAW comparisons to exact boards precede completion. No visual acceptance
or missing-reference match is invented by the grant. Core remains protected;
independent restyling continues, unsupported DAW/AI actions remain honest.

## Historical authority — COORD-010, 2026-10-15 (amended above)

[Owner-delegated grant](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6202569659): Agent B has full creative and implementation
authority for the visual experience, including layout/colour/type, scene geometry,
visual rendering, lighting/atmosphere, camera/animation/effects, responsive and
presentation interactions. May replace/refactor components and related tests;
**no lead approval for individual ordinary design decisions**. Older palette-only,
fixed-camera/geometry, CSS-only and per-file approval restrictions are superseded.
Product references and Logic-inspired full professional DAW intent remain context
for design, not a permanent three-lane limit or a per-choice approval gate.

Core audio rendering/DSP, real SYLUNE, authoritative models, application/domain,
storage/history/recovery, IPC/security, dependencies/build stay lead-owned.
Preserve functional workflows and honest unsupported/prototype states; document
necessary impacts and escalate only genuine core/contract/workflow risks. Verify
keyboard/accessibility, reduced motion, performance and real screenshots at
1120x700/1480x920. The [current handoff section 11](../engineering/UI_IMPLEMENTATION_HANDOFF.md)
and [AGENTS](../../AGENTS.md) govern ownership/conflicts; old inconsistent wording
below is historical. No new dependency, merge or destructive Git authority.


**2026-10-15 COORD-007 clarification:** the owner's later full professional DAW
brief uses **Logic Pro as the structural/workflow reference** (multitrack timeline,
headers, mixer/channel strips, buses/routing, processors/plugins, automation and
arrangement). Reference 1 remains appearance; Reference 2 may inform shell layout
where compatible. The earlier "not a layout target" wording below is historical
where it conflicts with this later structure decision. Project/Reference/Master
are not a permanent three-lane domain model. Future DAW surfaces and labelled
SYLUNE prototypes may be designed now without implying those engines exist.
[Explicit UI grant and capability/port rules](../engineering/SYLUNE_PRESENTATION_CONTRACT.md).
This does not re-open settled appearance, fonts, textures or Orbit API decisions.

**Updated: 2026-10-15. Status: owner-settled visual/sequence decisions; Slice A implementation follows the bounded [COORD-006/UI-004 handoff](../engineering/UI_IMPLEMENTATION_HANDOFF.md) after actual merge M and worker preflight/ownership acknowledgment.** [AGENTS.md](../../AGENTS.md) governs ownership; [PROJECT_GUIDE.md](../engineering/PROJECT_GUIDE.md) distinguishes implemented capabilities from future DAW concepts. This is the single design-direction brief; task-specific audits/proposals should reference it, not create competing briefs.

## Identity and usability

**Reference 1 is the visual target; Reference 2 is layout structure only. Ground-up redesign of presentation, not an extension/skin of the old interface.** Logic Pro remains a professional-usability reference, not an additional competing visual/layout target. MusicOnVerse must retain its own classy, welcoming, professional dark/celestial identity. It must not feel like a beginner toy, game interface, or SaaS dashboard.

The working surface is functional first. Waveforms, meters, names, time values, editing precision, and long-session comfort outrank decoration. Cosmic styling belongs chiefly in branding, onboarding/empty states, and restrained peripheral accents. No moving/glowing layer may reduce readability, obscure audio, steal focus, or consume resources needed for playback/rendering.

Preserve working interactions and contracts. A visual rearrangement does not authorize new DSP, session serialization, routing/state architecture, or framework/dependency changes.

## Workspace direction and priority

**Slice A comes first:** current-capability shell, navigation, transport and central workspace, readable responsive states and preserved existing actions. The owner has approved the target/sequence; agent-b supplies its bounded file/check plan and reports concrete tokens/results, not another request to settle the same choices.

**Orbit Mode follows as a separate spike**, after Slice A acceptance, in a separate module behind a default-off feature flag. Keep the existing `createStage` API unchanged. Reduced-motion **camera** behavior belongs to that spike, not Slice A. Compare ringed planet, moon terminator, atmospheric limb and ring to Reference 1 at **1120×700 and 1480×920**, reporting actual matches/gaps. No such comparison has been performed by the lead.

Longer-term component priorities below are not a mandate to invent missing features in Slice A:

1. Shell and clear navigation.
2. Transport, timeline, and central workspace.
3. Track headers, lanes, and arrangement.
4. Mixer.
5. Inspector.
6. Plugin presentation.
7. Complete applicable UI states.
8. Cosmic refinements.

This ordering is design direction, not a task assignment or a claim those capabilities exist. Current single-buffer workflows must remain usable. Real multitrack editing, mixer/routing, project history, hosted plugins, and Linked Sessions await core contracts/mechanism proofs. Keep unsupported actions honestly unavailable; static concepts must be unmistakably labelled concepts, never functioning-looking controls that do nothing.

Proposals should establish clear transport/context, a dominant editing surface, consistent selection/focus, and optional inspector/mixer regions. Avoid dashboard-card fragmentation and permanently competing visual panels. Present the same underlying authoritative state; do not create UI-only routing, processors, linked-item freshness, or duplicate session models.

## Token system to specify in the proposal

Define a coherent ground-up token/component system from Reference 1, using Reference 2 only for layout. Reusing proven behavior does not require extending the old visual theme. Record actual token values/results in the worker delivery for coordinator review; no final measured colour/gradient values are invented here. Ordinary implementation choices within the approved reference do not require another owner round-trip; material departures do.

| Semantic family | Required design decisions |
| --- | --- |
| Surfaces | Canvas, panel, raised/popover, recessed/input; subdued neutral-dark hierarchy |
| Text | Primary, secondary, muted, inverse; readable even in dense views |
| Borders/focus | Subtle/default/strong separators, selection, clearly visible keyboard focus |
| Accents | Restrained celestial brand accent vs functional action/selection accent |
| Feedback | Success/warning/error/info and current/stale/missing states; never colour alone |
| Typography | Readable UI stack; display/brand type sparingly; tabular/monospace numeric treatment |
| Spacing/sizing | One consistent scale; compact desktop controls with usable hit targets and touch adaptations |
| Shape/depth | Consistent corners, borders, shadows; depth communicates hierarchy, not gratuitous glow |
| Motion | Minimal transitions; reduced-motion/static-workspace behavior and performance budgets |

Avoid tiny, widely tracked uppercase labels for essential controls/data. Font option A is concretely mapped to approved **self-hosting**: sparse Orbitron brand/display, readable Rajdhani UI, Share Tech Mono readouts, and system fallbacks. Pinned WOFF2/OFL assets and provenance are [reviewed and prepared](../../src/assets/fonts/README.md); Slice A removes runtime Google-font requests, uses explicit inline packaging and exposes complete licences. No npm dependency is added. Typography, fallback glyph coverage and actual contrast still need UI checks. Do not infer unmeasured accessibility or licence compliance in a shipped bundle merely from source files existing.

## Reusable component vocabulary

Define consistent presentation and states for:

- Application shell, navigation, toolbar, transport, time/readout, context menus.
- Buttons/icon buttons, inputs, selectors, tabs, tooltips, dialogs, notices, progress/cancellation.
- Waveform/timeline surfaces and, only with real backing capabilities, track headers/lanes, mixer strips, inspector sections, processor panels.
- Source/linked-item identity, used-vs-available revision labels, affected-item review, compatibility/missing-dependency explanations when those core contracts exist.

Names and imported metadata are untrusted: render text safely, do not interpolate raw values as executable HTML. Maintain stable selection, focus, scroll, and control state through view updates. Do not hide errors behind a success toast or animate progress unsupported by the real operation.

## Accessibility, endurance, and responsiveness

- Target WCAG AA contrast: 4.5:1 for normal text, 3:1 for large text and essential non-text control boundaries/states. Measure actual colours; do not declare compliance from appearance.
- Keyboard-operable actions, visible focus, semantic labels, meaningful disabled states, non-colour status cues; no hover-only essential controls.
- Keep values/units readable, permit zoom/scaling, and make dense desktop controls usable without sacrificing touch hit areas in narrow layouts.
- Collapse/reveal secondary panes at smaller widths; do not squeeze the entire desktop DAW into unreadable miniatures. Preserve access to core actions and clear navigation.
- Evaluate representative desktop and narrow web viewports. Electron currently enforces a 1120 x 700 minimum; web mobile support is a separate test claim.
- Preserve existing CSS reduced-motion behavior in Slice A. Fully calm **camera** behavior is part of the later Orbit Mode spike, not a Slice A dependency. Background energy is never required to understand playback or status.
- Long-session comfort, meter/waveform clarity, and stable layout take priority over showcasing effects.

## State and capability honesty

Specify applicable empty, loading, ready, active, selected, disabled/unsupported, error, cancellation-requested/cancelled, and recovery states. Persistence, undo, cancellable computation, plugin hosting, or linked updates cannot be advertised before implementation and validation.

Future linked-item UI must distinguish a usable committed asset, a newer source revision, unknown/missing dependencies, incompatible update, and failed/cancelled render. Source edits must never silently replace audio. UI cannot bypass the approved operations or the manual-update invariant.

## Ownership and review

agent-b owns the bounded Slice A presentation reservation under the dated handoff once actual M and its independent preflight/ownership acknowledgment activate the grant. Onboarding alone is not an assignment. Publish the audit/file/check plan before edits; lead reviews contract preservation and results. The owner has settled Reference 1/2, ground-up presentation, self-hosting and Slice A/spike order; do not ask again. New consequential product/dependency/contract departures still require review.

The handoff—not this general brief—defines the exact file allowlist/denylist. Slice A includes scoped presentation in `src/main.js`, styles/entry and specified new presentation/font/texture/test paths; it excludes `src/ui/draw.js` and scene/camera implementation. `src/main.js` has a dated exclusive handoff; no concurrent lead editing. DSP/application/domain/storage/IPC/configuration/dependencies remain protected. Use locally generated/procedural textures, no texture CDN; static local assets use explicit inline imports. Required reference-provenance wording is in the handoff; no unsupported chart-track fingerprint or standards-grade claim.

Review the actual diff and functioning workflows, not screenshots alone. Run applicable regression/build checks, supply a runnable preview and screenshots where supported, and report manual/keyboard/viewport checks and omissions. No new test dependency without approval, no invented browser/macOS/listening results, and no automatic merge.
