# UI implementation handoff — COORD-006 / UI-004

## SUPERSEDED UI HANDOFF — 2026-10-16

P replaces B. [UI-RESET-001](UI_RESET_AUTHORITY.md) and its complete pre-deletion
inventory are current authority. Earlier B grants/old references/layout/fallbacks
below are historical, not active instructions. Core contracts/history/data remain
protected. Do not implement a new design before the owner supplies new media.


**Current authority: owner resolution, section 13 and [universe handoff](UNIVERSE_VISUAL_HANDOFF.md). It narrows conflicting earlier renderer/Orbit breadth; restyling continues, core remains protected.**

**Decision date: 2026-10-15 (Africa/Lagos).** Owner's final decisions supersede the earlier COORD-005 main-wait/read-only implementation restriction and the request to ask again about settled visual choices. Historical records remain evidence, not competing current instructions. [AGENTS.md](../../AGENTS.md) governs preservation; the [design brief](../design/DESIGN_BRIEF.md) remains the sole visual brief. This record supplies engineering decisions and a bounded assignment, not a second visual specification.

**Integration gate:** the lead reviews all of PR #3, fixes substantive findings, and uses the explicitly authorized `gh pr merge 3 --merge` only if review passes. The exact resulting main commit **M**, reviewed PR head, ancestry evidence and activation result are published in the **COORD-006 result comment on [PR #3](https://github.com/The-Mhood/onverse/pull/3)** after the operation. This file cannot contain its own future merge SHA. A proposed merge or this pre-merge document is not proof that M exists. Use the actual full published M, never a guessed SHA or a moving branch tip.

## 1. Settled scope and sequence

- **Reference 1 is the visual target. Reference 2 supplies layout structure only.** Logic Pro informs professional usability, not an extra visual target. Ground-up presentation redesign, not an extension/skin of the old interface; preserve application/audio/domain contracts and real workflows.
- **UI-004 / Slice A first:** current-capability shell, navigation, transport and central workspace; responsive presentation and honest states, reference provenance/copy, reviewed local fonts/notices. Existing single-buffer functions remain accessible. No invented working multitrack mixer, plugin host, Linked Sessions, backend or AI executor.
- **UI-005 / Orbit Mode spike afterward**, after Slice A review/acceptance and a separate source reservation. A separate module behind an explicit feature flag, off by default; proposed module location `src/scene/orbitStage.js`. It is not bundled into the Slice A assignment. Keep the existing `createStage(canvas)` API and returned `setSpectrum(arr)`, `setEnergy(v)`, `setPlaying(v)`, `dispose()` contract unchanged. No framework/new dependency.
- Reduced-motion **camera behavior belongs to that Orbit spike, not Slice A**. Slice A preserves existing CSS reduced-motion/accessibility behavior; it does not refactor the camera to satisfy a later spike.
- Test the ringed planet, moon terminator, atmospheric limb and ring against Reference 1 at **1120×700 and 1480×920** for the spike. Supply actual screenshots and element-by-element matches/gaps; do not claim physical/visual equivalence from API compatibility. Lead has not performed these comparisons or recovered reference image artifacts in this checkout. Agent-b uses the owner's supplied references in its context; report missing reference artifacts rather than substitute imaginary ones.

## 2. Fingerprint wording and actual provenance

This is **copy/wording provenance**, not a clipboard feature, asset identity hash or new measurement API.

Source inspection: `src/audio/genre.js` defines numeric `GENRES`/category profiles directly; no measured chart-track corpus, collection recipe or corpus licence/provenance accompanies them. `index.html` currently advertises “fingerprints of Spotify's top tracks”; genre comments and UI labels are not evidence of that claim. Do not present platform strings or hard-coded targets as independently measured platform recommendations.

Use these distinctions in Slice A, including entry-page metadata, explanatory text, reference labels and fallbacks:

| Actual path | Approved wording / required disclosure |
| --- | --- |
| Automatic/category choice → `matchGenre` / `categoryProfile` | **Built-in genre profile** — illustrative comparison target; not a verified measured chart-track fingerprint |
| Uploaded reference → `decodeFile` → local service analysis → `targetFromFeatures` | **Measured uploaded reference** — local analysis using experimental current meters |
| Apple Music preview → `fetchPreviewBuffer` → local service analysis → `targetFromFeatures` | **Measured Apple Music preview** — only the available preview, not the full streamed track; current meters remain experimental |
| Resolved metadata/category → `profileForResolved` | **Metadata-selected built-in profile** — full streamed track was not analyzed |
| No usable reference audio/category → existing auto fallback | **Built-in profile fallback** — reference audio unavailable; explain the actual fallback, not success at measuring a stream |

Suggested entry description: “Local audio analysis, reference comparison, processing and conversion.” Remove promises to fix everything, measure top-track corpora or support every format; show actual available formats. Do not rename profile fields/IDs or alter analysis/processing math as a copy fix. Preserve the supported reference-resolution workflow and its network/privacy boundary; this assignment adds no upload/provider. No standards-grade loudness, true-peak, limiter or safe automatic-gain claim is authorized.

## 3. Actual failure propagation and reviewed correction

`createAnalysisService` in `src/application/analysis/analysisService.js` forwards buffers/progress unchanged; its async methods return the engine result or reject with the original thrown/rejected value. It does not convert errors to empty success, move work off-thread, validate meters or implement cancellation.

Actual controller paths in `src/main.js`:

- Uploaded-reference analysis is awaited inside `ensureReferenceReady()`'s try/catch. A handled failure reports reference failure and returns `{ ok: false }`.
- Preview fetch/analysis is awaited inside a different try/catch. Its intentional failure policy is a notice and profile fallback, **not** propagation of a fatal measurement error or a claim that full-track audio was measured.
- `runAnalysis()` awaits preparation, then the main analysis and constructs/displays the target/result. Review reproduced a defect: preparation and control setup were previously **outside** its try/finally, so an unexpected preparation rejection escaped feedback/cleanup with `state.busy === true`.
- COORD-006 moves setup/preparation into the existing try/finally. Declined preparation returns through cleanup; rejection reaches the existing error feedback; finally clears busy, hides progress and refreshes reference controls. Error formatting also handles null/undefined non-Error rejection values. There is no engine/DSP change.
- Fast remeasurement used by crop/master-fix/rebalance continues to be awaited through the service in the existing controller flows. Service substitution is not whole-application runtime equivalence, rollback proof or a new worker implementation.

`tests/unit/analysisErrorFlow.test.js` evaluates the **actual source function** in a Node VM with explicit collaborators. The first eight cases were run against the unfixed source: 5 passed / 3 failed (preparation rejection, declined-preparation cleanup, setup failure). After correction, all nine current cases pass, including non-Error values. Tests cover guards, success, early decline, setup/service/progress failures and cleanup/error identity before result publication. They do **not** prove DOM resilience, browser workflows, real audio rendering, atomic rollback after a view fails, or immediate cancellation. Original first exploratory VM harness omitted a playback stub and was invalid; it was corrected before the successful reproduction and regression run.

## 4. Font option A and texture packaging: resolved

- **Option A = approved self-hosting**, concretely mapped here to Orbitron for sparse brand/display, Rajdhani for UI and Share Tech Mono for readouts, with system fallbacks. These are the existing verifiable families; no unavailable historical family proposal is fabricated.
- Reviewed, unmodified WOFF2 subsets, complete OFL 1.1 notices, package versions/registry integrity and per-file SHA-256 hashes are vendored under [src/assets/fonts](../../src/assets/fonts/README.md). Three pinned Fontsource packages at 5.3.0, downloaded into scratch, integrity verified; no npm dependency, manifest/lock edit, lifecycle script, runtime CDN acquisition or fee. Review covers licence/dependency provenance, not a formal legal/binary security certification. Actual glyph/rendering checks remain UI acceptance work.
- Slice A wires local `?inline` font URLs and accessible full `?raw` OFL text, and removes Google font links/preconnects. Assets are prepared in this baseline but **not yet wired into the old UI**. Don't mistake a successful baseline build for completed offline typography.
- **Textures: locally generated/procedural, no CDN or downloaded planet-texture dependency.** Prefer the existing Three.js CanvasTexture mechanism for the later spike; deterministic local generation needs no network/source-asset licence acquisition. If a small static texture is needed for presentation, store a locally authored PNG with provenance in `src/assets/textures/` and import it explicitly with `?inline`. No unreviewed external artwork.
- Existing `scripts/inline-dist.mjs` inlines JS/CSS, not arbitrary binary-relative URLs. An isolated proof using installed Vite and that exact inliner algorithm preserved a real inline WOFF2, a local PNG and full raw OFL text, with no external script/style/font/texture reference. This supports the packaging choice **at artifact level only**. Actual Slice A browser/file://, offline network and Electron behavior still require checks; no packaging configuration change is authorized/needed by this proof.

## 5. Exact handoff and exclusive ownership

**Dated boundary: 2026-10-15.** Lead completes the reviewed controller correction and integration first. On publication of verified M and the COORD-006 activation result, the following reservation is exclusively held for **agent-b on its existing fixed `arena/ced77c2a-onverse` branch in its own isolated checkout**. Lead freezes these UI/shared files until explicit release or coordinated re-handoff. Reservation is not evidence the worker has acknowledged or started; missing acknowledgment is never silently treated as one.

**Slice A write allowlist (new paths permitted only where stated):**

- `src/main.js`: presentation/templates and event binding only; preserve state schema, action semantics, awaited service calls, cleanup, reference decisions, processing/playback behavior and domain/application APIs. Ground-up DOM/CSS is allowed, not a core/controller/state rewrite.
- `src/style.css`, `index.html`.
- New presentation-only files under `src/ui/presentation/**` and `src/ui/styles/**`.
- New `src/assets/fonts/fonts.css` and `src/assets/fonts/notices.js` for the reviewed assets; do not overwrite vendored binaries, notices or manifest.
- New locally generated textures/provenance under `src/assets/textures/**`, with the inline packaging rule above.
- New presentation tests under `tests/ui/**`, using existing tools; no new dependency/test runner.

**Forbidden:** `src/audio/**`, `src/application/**`, `src/domain/**`, `src/ui/draw.js`, `src/scene.js`, `src/scene/**`, existing core/audio tests and fixtures, Electron/IPC, package/lock/build/config/scripts, other existing assets, and coordinator/architecture/design/queue documents. Forbidden wins. Orbit files are **not** part of this allowlist. Report necessary shared-contract changes instead of implementing them. The lead may work separately in protected core paths only with a new scoped assignment and no shared-file overlap; CORE-008 is still not dispatched.

**No early Slice A at `38484e894a283f43cbb36e05804990b7a4a73e88`.** The actual requested ground-up slice needs shared `src/main.js` action wiring, now including the corrected preparation/error boundary, accepted local service/plan seams and explicit handoff. It is not an isolated CSS experiment independent of its future baseline. Expedite reviewed M rather than create a second implementation on the stale audit base.

## 6. Worker activation: independent verification, then proceed

The lead inspected the available lead checkout/worktrees/remote refs/PRs; no published UI branch or UI worktree was accessible. Agent-b checkout cleanliness, unpublished commits, processes, runtime, reference artifacts and receipt **remain independently unverified**. Do not claim otherwise or move that checkout remotely.

Once the COORD-006 PR result publishes actual M, agent-b is **authorized to perform the following preflight and, if it passes and ownership is acknowledged, start Slice A without another owner/lead approval round-trip**:

1. Discover/report its own path/runtime, fixed branch and full HEAD; inspect status including untracked work, worktrees, relevant remote refs and active processes. Require its own isolated checkout, not the lead's directory or a shared editing worker. Preserve all work. Stop on unique commits/edits/unknown ownership, branch mismatch or tooling/access restrictions; no stash/reset/rebase/clean/force/switch workaround.
2. Fetch main. Obtain full M from the actual PR #3 COORD-006 result and independently confirm PR #3 is merged with that exact merge commit. Verify M exists, is reachable from fetched main, and contains the reviewed PR head/required baseline commits recorded in that result. The worker is checking actual objects/relationships, not trusting a branch label or this prose.
3. Require current UI HEAD to be an ancestor of M (`git merge-base --is-ancestor HEAD "$M"`); otherwise stop and preserve divergence. Inspect ignored/untracked collisions against incoming paths (including file/directory collisions), and ensure no active process can write them. A clean ordinary `git status` alone does not prove this. Do not authorize overwriting ignored work.
4. Only if all checks pass, on the **same fixed UI branch**, run `git merge --ff-only "$M"` with the exact approved full SHA. Verify after-HEAD equals M and status remains clean. No branch switch, reset, discard, rebase, history rewrite or unreviewed moving-tip substitution.
5. Publish a **UI-004 acknowledgment on PR #3** containing before/after full SHAs, ancestry/collision/status evidence, isolated path/runtime, exact ownership/allowlist acknowledgment and the bounded implementation/check plan. This mechanically verified acknowledgment activates the grant; it does not wait for a new product decision. Lead reservation is already exclusive. Do not label the task running without that actual acknowledgment.
6. Implement/review Slice A in small reversible commits, push only the UI session's fixed branch, then open its PR into main. Publish actual results, screenshots/preview where available, failures/skips and release request. No self-merge, no broader Orbit work before separate assignment/acceptance.

## 7. Whole-PR review and validation record

Review scope is the **entire PR #3 cumulative change**, not just its production refactor. The baseline reviewed at this task's start was `1b2c351ae4b4a2218bcb99e0439198dc7a92041e` (11 commits / 25 files). Supplemental changes are the error boundary/test, reviewed font assets/provenance, this scoped handoff and reconciled current onboarding notices. The final pushed head and merge outcome are recorded in the live PR result.

| Reviewed area | Findings / disposition |
| --- | --- |
| Production analyzer and analyzer regression/PCM fixtures | Channel-aware peak/clipped-frame/mean-channel energy and short-FFT padding are bounded changes with regressions; legacy LUFS, interpolated “true peak” and dangerous automatic-gain limitations remain explicit, not repaired/certified here |
| Analysis service + unit tests; processing-plan builder + unit tests; all controller substitutions | Async error/progress/input identity and trusted-plan behavior reviewed; fix the preparation/cleanup defect above; no imported-plan validator, worker or new state model implied |
| Native reference C, pinned-source runner, JS research candidate, comparator, metering recipes/tests | Fetches/hash checks/native build remain isolated test tooling; retained source notices; supported profile/rejection/boundary/chunk controls checked. Research stays outside production and does not confer normative certification |
| Metering contract and evidence | Distinguishes proposals, executed synthetic controls, provenance, dangerous existing gain and missing official vectors/independent broader conformance; no research API silently accepted |
| Architecture, product vision and roadmap | Reconciled PR #1 attribution; actual-vs-proposed boundaries, manual linked updates, relevant dependencies, destination preservation, transactions/recovery/graph safety and real proof gates retained. Commercial/POC/schema choices remain review drafts; planning cases are not executed/original-scenario coverage |
| Rules, README, guide, worker prompt, design brief, baseline decision, full queue | Ownership, links/fences/task IDs and historical-vs-current authority reviewed. Substantive stale read-only/extra-owner-approval instructions are superseded explicitly by this dated scoped grant; no invented worker receipt. PR #1 remains a separate unmerged draft |
| New assets, regression and handoff/onboarding diff | Only reviewed font members/notices copied, no new dependency; validate hashes, source boundary, grant intersection, local links and whitespace before final publication |

Executed on 2026-10-15 in lead Linux environment:

- Locked `npm ci --ignore-scripts --no-audit --no-fund`: 323 packages; no manifest/lock change. Deprecated transitive-package warnings retained; no fresh audit/security certification.
- Before the controller correction: default 145 tests / 142 passes / 3 known TODOs / 0 failures. The isolated eight-case new regression on unfixed source exited 1, 5 passes / 3 failures. Corrected current command `node --test tests/unit/*.test.js tests/audio/*.test.js`: **154 tests / 151 passes / 3 known legacy LUFS TODOs / 0 unexpected failures**.
- `node scripts/test-analyze.mjs`: all sanity checks pass.
- `MUSICONVERSE_STRICT_AUDIO_REGRESSIONS=1 node --test tests/audio/analyzerRegression.test.js`: exit 1, 47 tests / 44 passes / 3 known LUFS failures; not hidden or relabelled.
- `node scripts/validation/run-metering-reference.mjs --fetch`: pinned/hash-verified libebur128 1.2.6, 56 fixtures / 278 reference runs, 25 negative / 20 analytical controls pass. Upstream unused-variable warning; wrapper compiled with warnings-as-errors. Reference report SHA-256 `30acf2f7ea24f4dd277f470fec2be463e867d1e11bc16daf9cd0b77faf23b5ef`.
- `node scripts/validation/compare-loudness-candidate.mjs --reference /tmp/onverse-pr3-review-reference.json`: 56 fixtures / 278 runs, maximum difference **5.172680062059953e-9 LU**, zero chunk difference. Research files unchanged by this handoff.
- `npm run build` after source correction: succeeds, 17 modules, single-file inliner; >500 kB chunk warning remains. Vendored fonts are not imported by the old UI. Scratch inline asset/OFL artifact proof passes separately as described above.
- Local document links/fence pairs/unique queue IDs, font byte lengths/SHA-256/WOFF2 magic, protected manifest/lock/config/inliner diff and `git diff --check` are checked before publication. Final Git/PR HEAD/ancestry and main equality are rechecked around merge, not assumed.

**Not run / not claimed:** browser/UI/file:// font rendering, offline network observation, Electron/macOS startup or packaging/signing, actual listening, official metering conformance vectors, real Linked Sessions renderer/storage/recovery, worker checkout execution or either reference-image comparison. Owner-side tests remain deferred. These limitations prevent release/quality claims, not this bounded preservation-first UI assignment.


## 8. COORD-007 / UI-006 amendment — SYLUNE and existing Orbit, 2026-10-15

The owner's latest full-DAW/SYLUNE direction and the
[published Agent B decision](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6201376526)
supersede the no-future-concept/no-AI-facade language **only** for honest concepts
and explicitly labelled non-executing prototypes. Read the
[small presentation port](SYLUNE_PRESENTATION_CONTRACT.md) before implementation.
This amendment does not grant core functionality, retrospective acceptance or merge.

**Agent B exclusive UI reservation continues, including src/main.js.** New allowed
paths: `src/ui/presentation/sylune/**`, `src/ui/styles/sylune.css`,
`tests/ui/sylunePresentation.test.js`; initial files panel.js/contextActions.js.
Presentation/templates/events in `src/main.js` and `src/style.css` may wire a
collapsible panel, header icon and Ask SYLUNE. No controller state-schema/action
rewrite, raw model/state bridge, audio/service/processor/history changes or fake
execution. Lead does not edit these files concurrently; accepted core exports
are wired by Agent B, with explicit re-handoff if controller semantics must change.
All other original Slice A allow/deny constraints remain. No new dependency.

**UI-005 reconciliation:** actual draft PR #5 at full HEAD
`7222704026cf50fe8b62b212c7da5640e62381f5` includes five commits/13 files.
`a3db8c1` and `7222704` are the existing Orbit task, partially fulfilling UI-005,
submitted/not accepted. Continue reservation for `src/orbit/orbitStage.js`,
`orbitTextures.js`, `orbitKeys.js`, `tests/orbit/orbitStage.test.js`,
`orbitKeys.test.js`, and presentation-only main/style wiring. Do not create a
second spike or edit `src/scene.js`, `src/scene/**`, `src/ui/draw.js` or core paths.
The default-off flag, unchanged createStage API and motion/reference gates stand.
The earlier not-dispatched/no-file-grant record is historical, not today's state.
UI-004 acceptance remains outstanding for integration; it does not prevent the
new separately owner-authorized UI-006 presentation work after acknowledgment.

Lead independently reproduced 36/36 static/pure UI/Orbit tests; existing UI-branch
core 154/151 pass/3 known TODOs; sanity and build pass (28 modules, chunk warning).
Reviewed via a pinned temporary snapshot and scripts-disabled locked dependencies;
no worker workspace/history was changed. An initial archive-only attempt failed
for missing three/Git metadata; the corrected harness passed without source fixes.
Worker's browser/software-WebGL reports are not independently reproduced here.
No original reference artifacts are available in this lead checkout.

Next Agent B action: post its own current preservation/isolation/file-plan
acknowledgment on PR #5, then proceed within UI-006 and finish UI-005 evidence.
No further owner round-trip or session/branch switch. Supply durable reference
matches/gaps at 1120x700 and 1480x920; runtime reduced-motion, text-entry/shortcut,
manual drag/ease cancellation, resize/dispose and resource/performance checks;
retain existing workflow regressions. Tighten the UI scope test beyond dirty-tree
`git diff HEAD` to approved-base-to-HEAD plus tracked/untracked scope. The actual
published PR diff independently has no core/config/dependency changes.

Publishing this amendment is not proof of receipt, new edits or running status.
No self-merge/PR approval, provider, network upload or generated-code executor.


### Published proposal follow-up — UI HEAD 8a2e712

While coordination was in progress, Agent B published only
`docs/design/proposals/agent-b-daw-sylune-proposal.md` after tested `7222704`.
Preserve this non-canonical proposal; Agent B may update that exact proposal path
prospectively to reflect the published decisions, without editing canonical docs.
No tested UI source changed in that delta; no claim of re-running visual tests.

The panel/prototype/full DAW structure questions are resolved by UI-006. Do not
edit `src/domain/**` for UI structure. Existing Project/Reference/Master roles are
not real independent tracks/mixer/arrangement entities. Keep existing manual
master-fix accessible and truthfully labelled; do not gate it behind disconnected
SYLUNE or imply AI performed it. Prototype mixer/track controls remain disabled/
clearly labelled until actual accepted operations exist.

The proposal's alternate "approved cosmic mockup primary / Reference 1 secondary"
ordering is **not adopted by this lead** without verified later owner direction
and artifacts. Current canonical Reference 1 appearance remains. If later direction
already exists, publish its actual evidence for reconciliation; do not ask the
owner to repeat settled choices. This affects only target-change acceptance,
not independent SYLUNE/DAW scaffolding work. Workspace-wide CSS/presentation within
the grant is allowed, but no `scene.js` edit or making Orbit default-on.

Use the defined port rather than a separate askSylune/respondToProposal API.
Discard is a plan-bound host intent, not undo or silently retained approval.
Prototype labels thinking/previewing/completing may map to the v1 phases; they do
not create a measured analysis/preview/completion event. A real preview must be
labelled as such and never presented as a committed change.


## 9. COORD-008 — active four-decision blocker resolution / 2026-10-15

Published and available to Agent B on [PR #5](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6201768819).
This section supersedes inconsistent earlier restrictions within its exact scope.

Owner requested these decisions directly. This is an active, prospective lead grant, not another request for permission. Preserve both sessions, fixed branches and all existing work. Agent B stays on arena/ced77c2a-onverse; lead stays on arena/14df8ffa-onverse. No reset/clean/stash/rebase/switch/force-push/merge is authorized. Agent B posts its own current preservation/isolation preflight and exact file plan before edits, then proceeds without waiting for another approval reply. Posting this grant does not prove receipt/start.

### 1. YES — exclusive presentation reservation for Agent B

Agent B may edit presentation/templates/event wiring in `src/main.js`, and `src/ui/presentation/sylune/**`, to integrate the SYLUNE header icon, collapsible panel and contextual Ask SYLUNE. Also allowed: `src/ui/styles/sylune.css`, presentation-only `src/style.css`, and `tests/ui/sylunePresentation.test.js`. The reservation remains exclusive until explicit release/re-handoff; lead will not edit these concurrently. Existing Slice A grants continue.

Use the published v1 port: `mountSylunePanel({root,onRequest,onOpenChange}) -> {setOpen,setContext,render,dispose}`. Read-only context carries session/snapshot/relevant revision/selection/typed target IDs and capabilities, null when unknown. Host validates requests and supplies lifecycle/progress/results; unconnected real mode is unsupported. Prototype mode is deliberately selected and persistently labelled "Prototype — no audio changes". No fabricated analysis, live awareness, knob movement, execution or success.

Forbidden: controller state-schema/action semantics, audio/service/domain/application/storage/history/IPC changes; raw model/audio/path access; new provider/network/dependency/configuration. Lead owns functional adapters. If one is genuinely required, report the exact core symbol; do not edit it or let that block the presentation prototype.

### 2. YES — inert PROTOTYPE multitrack timeline and mixer

The current owner direction supersedes the older blanket ban on inventing a mixer for this visual prototype. Design the full Logic-inspired professional DAW: multiple tracks, headers, timeline/arrangement, transport, channel strips, buses/routing, plugins and automation. Project/Reference/Master are current roles, NOT a permanent three-track architecture or implemented tracks.

New engine-dependent controls remain inert/disabled with visible "PROTOTYPE — not implemented; no audio changes" labelling, not tooltip-only. Do not simulate audio, recording, routing or successful operations. Existing working import/analyze/reference/playback/A-B/crop/conversion/manual processing remain accessible and retain semantics. Keep manual master-fix truthfully manual, not behind a disconnected AI gate. Presentation fixtures are isolated demo data, never authoritative projects or real execution IDs.

**Functional session model / integration boundary (lead-owned; specified, not implemented):**
- One authoritative immutable session snapshot: stable session/snapshot IDs, version, sample rate/channel layout; ordered stable-ID audio tracks and regions referencing immutable media assets with checksums/frame ranges; track parameter revisions; explicit master/bus IDs, validated routing edges and ordered processor instances. Future automation/tempo and plugin parameter schemas are versioned capabilities, not guessed UI state. Reject missing targets, invalid units/ranges, incompatible layouts and unsupported/cyclic routes in the supported profile. No external plugin host is implied.
- UI receives a bounded read-only projection and capability registry from a host adapter; no second session/localStorage store. Unknown IDs stay null; labels never identify execution targets. The existing Linked Sessions contract is only a bounded gain/sum proof profile, NOT this full session engine.
- Real edits use typed host commands containing correlation/operation ID, target IDs, expected relevant revisions, validated parameters/units and supported operation type. Host re-resolves state, validates full dependency closure, prepares preview/review plan and requires plan-bound approval for SYLUNE changes before commit. Display revisions/unrelated edits do not automatically invalidate audio dependencies. A UI approve flag is not authorization.
- Core emits ordered context-bound operation events and actual parameter/result changes. Preview is distinct from committed output; cancellation becomes accepted only before the promotion barrier, otherwise explicit too-late; undo/redo require retained real generations/history. No functional controls are enabled until accepted exports, capabilities and integration tests exist. These are required semantics, not newly available JS exports.

Lead's next implementation remains the smallest actual approved-snapshot render -> generation/journal/pointer commit -> restart/recovery/undo loop, not a full-DAW prerequisite or unrelated backend rewrite. Agent B does not wait for that to build the labelled design.

### 3. YES — workspace-wide cosmic restyle via an approved shared-shell alternative

Ownership reviewed: `src/scene.js` is lead-owned legacy Three.js stage; `src/orbit/{orbitStage,orbitTextures,orbitKeys}.js` is Agent B's reserved Orbit stage. `src/main.js` selects the default/flagged stage. Existing `#stage` is fixed/full viewport with pointer-events none, and both stages expose the existing createStage contract.

**Authorize Agent B now** to add `src/ui/presentation/cosmicEnvironment.js`, `src/ui/styles/cosmic.css`, `tests/ui/cosmicEnvironment.test.js`, and shell mounting/workspace attributes in presentation-only main.js/style.css. Build one persistent non-interactive CSS/local-procedural background layer and shared palette/lighting/material tokens across the DAW, existing workspaces and Orbit shell; future workspaces inherit the same shell. No separate renderer, RAF loop, session store or dependency. Its API can be `mountCosmicEnvironment({root}) -> {setWorkspace,dispose}`; setWorkspace is a presentation label, not a fake workspace engine.

Use the shared base/tokens plus actual Orbit canvas when Orbit is enabled; suppress duplicate decorative planet layers in that mode rather than stacking two environments. Do not remove/replace the legacy stage, change its spectrum/energy/playing calls, steal Orbit pointer/keyboard input or instantiate a second stage. Default stays default; `?orbit=1` remains opt-in. Stable stacking: decorative layer cannot cover controls, waveforms, menus or focus rings; pointer-events none, aria-hidden, readable surfaces. CSS/static/procedural decoration is NOT a claim of a functional 3D environment in every workspace. Reduced motion must be static for the new layer; no automatic camera travel.

This is the approved alternative to editing scene.js; it needs no further owner review to begin. Lead retains `src/scene.js`, `src/scene/**`, `src/ui/draw.js` and stage API semantics. Agent B retains existing Orbit paths, including presentation-only palette/composition adjustments and tests within UI-005, not a stage API rewrite. If later true shared-3D internals are needed, lead reviews a separate exact handoff; do not block this approved restyle on that future change.

Keep settled Reference 1 appearance / Logic structure. No new reference-primacy decision or claimed visual match without actual artifacts and comparisons. Verify layer stacking/readability across current workflows, DOM keyboard access, reduced motion, switching/resize/disposal and performance; provide 1120x700 and 1480x920 evidence.

### 4. UI-005 = SUBMITTED / PARTIAL, NOT ACCEPTED — continue existing Orbit

PR #5 is open at `8a2e71263fd921aff133ce8e663f764f8062e55b`. `7222704026cf50fe8b62b212c7da5640e62381f5` is the existing Orbit implementation; 8a2e712 adds only a non-canonical proposal. The prior lead independently reproduced 36/36 UI/Orbit tests at 7222704, plus UI-core 151 pass / 3 known TODOs, sanity and build (chunk warning). These are recorded prior checks, not a new browser/visual run this turn.

Complete/submitted: feature-flagged Orbit stage, procedural textures, keys/HUD integration and passing static/pure tests. Not complete/accepted: reference composition at 1480x920 (explicitly not rechecked by worker this turn), durable 1120x700/1480x920 screenshots and match/gap reports, reduced-motion camera, editable-field/modifier/repeat shortcuts, drag cancelling focus ease, resize/dispose/performance, and preserved working flows. Prior worker runtime reports remain attributed, not independently verified acceptance. UI-004 acceptance is also not invented.

**Next authorized action:** Agent B continues existing `src/orbit/orbitStage.js`, `orbitTextures.js`, `orbitKeys.js`, `tests/orbit/orbitStage.test.js`, `orbitKeys.test.js` and presentation main/style wiring; capture/recheck 1480x920 and 1120x700 against actual references, report gaps, fix only within these paths, rerun tests/build and publish evidence on this PR. If a reference artifact is unavailable, report that specific validation gap; the granted implementation remains unblocked. No duplicate spike, default-on flag or completion claim based only on 36 tests. Strengthen scope testing to approved-base-to-HEAD plus tracked/untracked edits, not only dirty-tree `git diff HEAD`.

### Next steps / task states

- Agent B: record preflight/file plan once; UI-006 panel/Ask and labelled DAW prototype are ready, new UI-007 shared cosmic shell is ready, UI-005 continues submitted/partial. Work in bounded commits on the same branch; link real test/viewport evidence. Update the existing non-canonical proposal to remove resolved blockers; do not edit canonical coordinator docs.
- Lead: freeze the UI allowlist, own canonical queue/session/application contracts and real renderer/storage integration, validate actual runtime/visual evidence before acceptance, and coordinate any later functional exports without concurrent main.js edits.
- No merge/release/production AI/full DAW claim, dependency change or new owner decision is included. Neither publishing nor a screenshot demonstrates receipt or real execution.


## 10. COORD-009 / UI-008 — active canvas palette exception

Published on [PR #5](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6202421591).

I read your actual report [6202217727](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6202217727), fetched PR #5 at `0a9b164091e70d069d6dadf67e86d49fac958f7a`, and inspected draw.js/scene.js. Your canvas palette gap is valid. **The narrow reservation below is granted now.** This supersedes the previous blanket no-edit restriction ONLY for these colour substitutions. No further owner colour/architecture decision or session switch is required.

### Exact scope and ownership

Agent B has an **exclusive colour-only editing reservation** for:
- `src/ui/draw.js`: radar, waveform/crop/playhead colour values.
- `src/scene.js`: legacy SCAN-stage particle/spectrum/torus/core colour values.
- New optional helper `src/ui/presentation/canvasPalette.js`: a small pure projection of the current theme palette, not a second theme or app store.
- New `tests/ui/canvasPalette.test.js`; existing B-owned `tests/ui/presentation.test.js` may add only these exact newly authorized paths to its scope guard. Do not replace the guard with a broad src/ui or scene exemption.
- Existing B-owned main/style/cosmic/Orbit presentation reservations continue; no extra core paths are opened.

**Lead freezes all edits to draw.js and scene.js until Agent B explicitly releases this reservation and lead records the re-handoff.** Core retains semantic/API ownership, but there will NOT be simultaneous lead logic edits and worker colour edits in either file. Lead's current Linked Sessions work does not need these files. src/scene/** remains forbidden; this is not a directory grant or a geometry/camera redesign.

### What is permitted / what must stay identical

Replace decorative RGB/hex colour values with the existing Reference 1-derived CSS palette already present in your branch (e.g. current primary/secondary/accent/success/neutral token values), not a new art direction. A pure side-effect-free helper is allowed; keep it aligned with existing CSS through a parity test. No DOM reads at module import, sample iteration or RAF; no new dependency, provider, renderer, event loop or model. Renaming a colour-only constant is okay; no other refactor.

Preserve all alpha/opacity values, blend modes, shadow blur, gradient stop positions, array counts, geometry, buffers, score calculations, peak cache, channel handling, amplitudes, crop/progress coordinates, timing/easing, camera, reduced-motion behaviour, listeners, resize/disposal and input semantics. No shader-logic edit. Preserve drawRadar/drawWaveform signatures and createStage(canvas) -> setSpectrum/setEnergy/setPlaying/dispose API and call sites. Keep original/processed waveform and crop/playhead meaning visually distinct; do not erase warning/error/success semantics by tinting everything identically. The default stage remains default; Orbit remains opt-in, with its existing separate reservation.

If palette completion genuinely requires anything beyond that, report the exact expression and reason before expanding scope. This is not permission to modify analyzers, services, application/domain, storage/history, Electron/IPC, manifests/lock/build config, existing core tests or canonical coordination docs.

### Next authorized action / acceptance

Post a short current file-plan/boundary acknowledgment here, then proceed **without waiting for another approval reply**. Keep same session/fixed branch and preserve all existing work. Implement a small palette-only patch, not a rewrite. Rerun UI/Orbit tests and build; do not weaken tests. Verify before/after drawing commands/coordinates and unchanged peak/crop/playback meaning with targeted tests. Review the cumulative published scope plus tracked/untracked deltas, not just dirty-tree diff.

Supply before/after SCAN/radar/waveform/default-stage and opt-in Orbit screenshots at 1120x700 and 1480x920, plus native canvas/WebGL smoke checks. Report any missing references/runtime checks honestly. Passing this palette review alone does not accept UI-004/005/006/007 or certify performance. Your 53/53 tests, build, screenshots and browser checks at 0a9b164 are currently worker-reported, not newly independently reproduced by lead. UI-006 and UI-007 are now submitted, not accepted; UI-005 remains submitted/partial. The reported Orbit reduced-motion/disposal/context gaps and software-WebGL performance limits remain open.

### Functional boundary remains unchanged

Correct: real SYLUNE execution and multitrack audio are core work. Current lead code has a bounded native renderer and review/approval/cancellation service; the real generation repository/transaction/recovery join is next, not yet implemented. Do not enable execution, real-track/mixer capabilities, fabricate knob motion or infer session awareness. Continue the visibly labelled inert DAW prototype and unsupported/not-connected real mode independently of core completion. This palette grant requires no functional engine.

### No Git realignment authority

Your report also asks about local-ref realignment. This colour grant does NOT authorize mixed reset, update-ref/ref rewriting, stash/clean, switching, force push, or overwriting preserved work. Keep that separate from the now-resolved palette ownership issue; if the actual checkout prevents a safe edit/publication, report its exact constraint without rewriting it. No PR merge/approval or receipt/start is inferred from this comment.


## 11. Historical COORD-010 broad visual authority / 2026-10-15 (amended by section 13)

Published on [PR #5](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6202569659); effective now, not pending individual design approval.

The product owner explicitly replaces the earlier narrow presentation grants with the authorization below. **No further lead approval is required for ordinary design, layout, styling, animation, visual rendering or presentation refactoring within this grant.** This supersedes COORD-006/007/008/009 restrictions where they conflict with this authority, not their core-safety/preservation requirements. Existing work is preserved; no task is retroactively accepted.

### 1. Full design and visual implementation authority

Agent B owns MusicOnVerse's visual experience: layout, colours, typography, scene geometry, graphics rendering, cosmic environments, lighting, atmosphere, camera movement, animation, effects, responsive behaviour and presentation interactions. Agent B may restructure or replace presentation components and refactor their tests without approval for individual design choices. Existing product direction/references remain design context, not a requirement to ask the lead to approve every interpretation.

The reservation includes presentation responsibilities in `src/main.js`, `src/ui/draw.js`, `src/scene.js`, related `src/scene/**`, `src/orbit/**`, `src/ui/**`, `src/style.css`, `index.html`, presentation styles/assets/font resources and related UI/Orbit/scene tests. This is not permission to move core code into a UI directory and call it presentation. Font/asset licensing, local provenance, safe content handling, dependency/build/security boundaries still apply.

Old colour-only, immutable geometry/camera, CSS-only cosmic shell, no-extra-visual-renderer/RAF, fixed palette and narrow per-file presentation approval gates no longer limit this visual work. Internal presentation APIs may be refactored with their owned callers and tests. A real application/audio/IPC contract change is different and must be coordinated with lead. Presentation workspace/scene switches may be redesigned; they cannot enable an unsupported audio/AI capability or silently break working flows.

### 2. Professional DAW, Orbit, shared environment and SYLUNE presentation

Agent B may build/refine the full Logic-inspired professional DAW interface, multitrack timelines, mixer/visual controls, Orbit workspace, shared cinematic environment, SYLUNE panel and contextual interactions. Current Project/Reference/Master roles do not permanently constrain the design. Honest interactive visual prototypes are allowed, with persistent clear labelling that unsupported audio/track/routing/AI operations are not implemented and make no audio changes.

Do not fabricate analysis, session awareness, knob/audio execution, measured progress or results. Distinguish existing functional controls, deliberate prototype/demo state, and real unsupported/not-connected state. Keep demo data separate from authoritative project/parameter state.

### 3. Core functionality remains lead-owned

**Visual/scene rendering is Agent B's; audio processing/rendering engines are lead-owned.** Also lead-owned: functional SYLUNE intelligence/planning/execution; authoritative session/track/asset models; application/domain logic; persistence/storage/history/recovery; IPC contracts/security; dependencies/build configuration; and other core services/operations. Do not redefine, duplicate, bypass or independently modify these.

In shared main.js, Agent B may reorganize presentation/templates/listeners/visual adapters and preserve existing functional action/service bindings, but may not independently change their authoritative state transitions, DSP, validation, approval, execution or persistence semantics. Existing audio buffers may be consumed by supported visualizers; this does not authorize changing audio or analyzer calculations.

### 4. Exclusive file coordination and integration

Lead freezes source edits in Agent B's reserved presentation files, including whole shared main.js/draw.js/scene.js files, until explicit release/re-handoff. There will be no simultaneous lead core edits and Agent B design edits in those files. Core semantics ownership is not concurrent file-editing permission.

Identify a genuinely required core integration by exact interface/symbol, payload, capability and expected behaviour through this existing PR coordination channel. Lead implements/reviews the core contract, then Agent B wires accepted exports in its reserved presentation files. Do not create another core implementation or block independent UI work while waiting. Report file plans/preservation and results for coordination, not as requests for routine design approval. If a real ownership collision appears, pause only the affected file/integration and continue disjoint work.

Coordinator ownership remains with lead for AGENTS/canonical architecture/engineering queue/ownership records. Agent B can maintain its existing non-canonical design proposal and presentation documentation; propose canonical changes here rather than creating a competing authoritative record.

### 5. Quality and preservation

Preserve working user workflows unless a necessary change and its impact are documented. Escalate a change that genuinely risks breaking a functional workflow before that affected change; do not treat every visual refactor as such a risk. Keep real import/analyze/reference/process/playback/A-B/crop/export/conversion/error flows honest and usable.

Run relevant tests/builds without weakening coverage; validate keyboard/focus/accessibility, responsive behaviour, reduced motion and performance. Provide actual screenshots at **1120x700 and 1480x920**. Report regressions, missing references and unfinished integrations honestly. Graphics features/camera/animations now fall within design authority, but require correct reduced-motion handling, resource/listener disposal and actual performance evidence. Test/build/screenshot reports are not automatic acceptance or production certification.

### 6. Existing sessions, branches and bounded delivery

Continue in the existing workspace and fixed branch: Agent B arena/ced77c2a-onverse, lead arena/14df8ffa-onverse. Preserve all local, untracked, ignored and published work. No session/branch switching, destructive Git operations, history rewriting, merging or overwriting unrelated work without explicit authorization. Deliver bounded, reviewable commits and publish actual evidence here.

The separate reported local-ref realignment issue is NOT authorized by this visual grant: no mixed reset/update-ref/ref rewriting/force workaround. Report an actual preservation/publication blocker without altering history or letting it masquerade as missing design authority.

### Approval rule / immediate next action

**Proceed within this grant without another lead approval round-trip. Escalate only a genuine crossing into core, a new architectural/core contract, or a risk to an existing functional workflow.** Normal design/scene/internal presentation refactoring and related tests do not need individual approval.

Continue the existing UI/Orbit/SYLUNE/cosmic work rather than starting duplicate implementations. Prior palette task UI-008 expands under this grant; UI-004/005/006/007 submissions retain their actual review status. Current PR head inspected: 0a9b164. No new implementation, receipt/start, test reproduction, PR approval or merge is implied by this authorization. Lead continues core repository/render/recovery work separately.


## 12. Product-integration interface decisions — 2026-10-16

Current inspected PR5 head: `08f87407358890754d6dd4bdb76a8096b46eeb50`.
Read reports6202957304/6203299537/6210528201 and inspected the nine-file delta
from0a9b164 via GitHub API; no checkout/cherry-pick/ref realignment. Worker reports
67 UI/Orbit tests/build/screenshots, not independently rerun/accepted by lead.
UI-005 remains submitted/partial: dock overlap at1120, ring rendering,
reduced-motion/performance/disposal/control evidence remain unresolved.

- **Save-state contract resolved, implementation pending:** use
  [SESSION_APPLICATION_IPC.md](SESSION_APPLICATION_IPC.md), read-only
  `getPersistenceState`/`onPersistenceState` under future `window.movSessions`.
  Exact DTO and status semantics are specified there. No actual preload endpoint
  exists yet; retain "Not saved · session only" when absent. No localStorage,
  file-mtime/animation inference, mock "saved" events or direct Linux store calls.
  Implement a disposable presentation subscriber/formatter if useful; do not wait
  for host implementation to continue independent design.
- **Auto-opening report/Fix rail is presentation interaction, already B-owned.**
  B may stop automatically revealing the rail after a successful analysis or
  redesign its placement. Keep real result/error rendering and manual report/Fix
  access obvious and keyboard accessible; preserve analysis state, processing,
  approval, A/B and error semantics. In current worker main, visibility is changed
  in `renderReport`; changing automatic presentation visibility there does not
  transfer ownership of analysis math or state mutation. No request for another
  ordinary design approval is needed. No lead concurrent main/style edits.
- Continue fixing dock overlap/rings/responsiveness and re-run actual accessibility,
  reduced-motion, performance/resource-disposal/control checks. Don't mark known
  gaps complete from code inspection alone. No merge/ref-rewrite authority.

Owner's latest current-core hold: no commit/push/merge/release of reviewed core
changes until review/next action clear. This interface notice is not a production
capability release, worker receipt or PR acceptance. Core remains lead-owned;
full COORD-010 visual grant remains active without engine-based blocking.


## 13. COORD-010 owner resolution — universe, art, palette, Sora / 2026-10-16

[Exact published decision](https://github.com/The-Mhood/onverse/pull/5#issuecomment-6213314954).

[Exact current implementation plan and gates](UNIVERSE_VISUAL_HANDOFF.md).
Approved shared Three.js renderer in `src/ui/presentation/universe/**`, necessary
main.js stage factory/ORBIT_SPIKE wiring, unchanged public createStage contract.
No unrestricted orbitStage.js or directory-wide permission: inspected initial
Orbit diff is empty, preserve it as rollback. A later required camera/motion diff
must identify exact symbols/hunks/tests before specific approval. Proof opt-in,
verified default promotion, explicit old-stage/classic rollback.

Latest boards govern both opening universe and DAW, including violet/magenta/
electric-blue/cyan/warm highlights, not generic neon/steel-blue/monochrome purple.
Exact sourced/original art license/attribution/used-file manifest required;
procedural placeholders do not meet fidelity by default. Sora candidate files
are pinned/reviewed in SORA_ASSET_REVIEW.json; B may integrate exact files with
full OFL/manifest/notices, existing fonts fallback pending build/browser checks.
No additional dependency, core operation or unrelated renderer changes.

Independent studio/presentation work proceeds now. Completion requires baseline/
revised performance, actual reduced motion, inspected1480x920 studio and opening/
DAW board comparisons, screenshots/tests/build/cleanup and explicit remaining gaps.
No lead presentation edits, worker receipt, visual acceptance or Git release claim.
